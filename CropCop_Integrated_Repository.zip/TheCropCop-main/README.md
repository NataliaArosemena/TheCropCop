# The Crop Cop — integrated ROS1 simulation prototype

**Important:** This repository currently targets **ROS Noetic / Ubuntu 20.04 / Gazebo Classic**, because the existing GitHub project and the attached planning sheet use ROS1 `catkin_make` and `roslaunch` commands. The sheet also lists *future ROS2/Nav2 migration*, which is **not implemented**. A native ROS Noetic install is not supported on Ubuntu 26.04. Use a compatible Ubuntu 20.04 environment or migrate the project separately.

The original `the_crop_cop/labs/` coursework, `field_patrol.py`, and empty draft scripts are preserved. **Do not run `field_patrol.py` alongside the new decision node**; both would publish `/cmd_vel`. For the integrated demonstration, the **only** `/cmd_vel` publisher is `decision.py`.

## Quick start (Ubuntu 20.04 + ROS Noetic)

Install/confirm ROS Noetic, Gazebo Classic, TurtleBot3 Gazebo/description, `ros-noetic-cv-bridge`, `ros-noetic-tf`, and Python OpenCV and NumPy. This repo is a catkin package inside a repository folder, not a catkin package itself.

```bash
mkdir -p ~/catkin_ws/src
cd ~/catkin_ws/src
# Either clone the repo or extract this ZIP here. Ensure package is under src:
# ~/catkin_ws/src/TheCropCop/the_crop_cop
cd ~/catkin_ws
source /opt/ros/noetic/setup.bash
catkin_make
source devel/setup.bash
export TURTLEBOT3_MODEL=waffle
roslaunch the_crop_cop crop_cop_demo.launch
```

If catkin does not find the package because the repository is nested, make a symlink:

```bash
ln -s ~/catkin_ws/src/TheCropCop/the_crop_cop ~/catkin_ws/src/the_crop_cop
```

An alternative is to copy just `the_crop_cop/` directly into `~/catkin_ws/src/`. **Do not use both the copy and the symlink simultaneously.** The Gazebo world is generated with four planter beds, 12 green plant proxies, a red bug, a green bug, and an obstacle. The default launch also attempts to spawn a TurtleBot3 Waffle.

## Inspect demo topics (new terminal with sourced workspace)

```bash
rostopic list
rostopic echo /crop_cop/state
rostopic echo /crop_cop/alert
rostopic echo /crop_cop/insect
```

Expected robot inputs: `/odom`, `/scan`, `/camera/rgb/image_raw`; check your TurtleBot3 variant using `rostopic list`. A missing `/scan` or `/odom` prevents movement intentionally. The camera topic may need updating in `config/crop_cop.yaml`.

### Synthetic smoke tests (camera not required)

```bash
rostopic pub -r 5 /crop_cop/insect std_msgs/String 'data: "BAD"'
# Interrupt the above after seeing PEST_ALERT and an alert message.
rostopic pub -1 /crop_cop/battery_pct std_msgs/Float32 'data: 10.0'
rostopic pub -1 /crop_cop/battery_pct std_msgs/Float32 'data: 30.0'
```

These tests drive simulated decision logic, not a pump. `/crop_cop/state` changes to `RECHARGE_REQUEST` below 15% and resumes when battery >20%, subject to valid patrol commands. No battery source is simulated by default (the node starts at a fictional 100%); no solar charging, charging-route planner, external phone alerts, or automatic spraying is implemented.

## Architecture

`camera` → `vision.py` → `/crop_cop/insect` → `decision.py`

`odom + lidar` → `patrol.py` → `/crop_cop/patrol_cmd` → `decision.py` → `/cmd_vel`

`battery_pct` → `decision.py` → `/crop_cop/state`, `/crop_cop/stop`, `/crop_cop/alert`

The controller uses simple aisle waypoints in odom coordinates and reactive LiDAR turn-in-place. This is **not** SLAM, Nav2, guaranteed collision-free navigation, or validated insect recognition. Green classification is off by default because ordinary plants share its hue range. The fake red sphere can be detected only when visible in the camera's view at sufficient pixel area.

## Further work and traceability

See `the_crop_cop/docs/REQUIREMENTS_MATRIX.md`, `TEST_PLAN.md`, `BOM.csv`, `PROGRESS.md`, and `INTEGRATION_NOTES.md`.
