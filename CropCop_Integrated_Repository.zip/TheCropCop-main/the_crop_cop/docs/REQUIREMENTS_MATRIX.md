# Requirements traceability to the attached 3-page project plan

| Plan requirement | Current implementation | State |
|---|---|---|
| Gazebo garden environment | `worlds/crop_garden.world` four beds/12 plants/2 bug proxies/obstacle | Authored; runtime unverified |
| CAD design for robot | Upstream TurtleBot3 Waffle simulation model selected | Existing model only; custom CAD not completed |
| Visit several plants autonomously | `scripts/patrol.py` and odom aisle waypoints | Authored; behavior unverified |
| Avoid obstacles / crop keep-out | `patrol.py` front LiDAR stop + rotate; aisle waypoint design | Reactive only; no mapped keep-out zones |
| Stop and alerts | `decision.py` publishes zero velocity and alert topics | Authored; runtime unverified |
| Harmful/helpful bug colors | red BAD / optional green GOOD HSV, green disabled to avoid plant false positives | Demo heuristic, not species recognition |
| Stationary, randomized insects | Two stationary colored Gazebo spheres | Randomization not implemented |
| Owner verification of abnormality | `/crop_cop/alert` text requests verification | No email/SMS confirmation loop |
| Patrol/pest/recharge FSM | PATROL, PEST_ALERT, RECHARGE_REQUEST | Prototype; recharge routing not implemented |
| Battery threshold (15%) | `/crop_cop/battery_pct` Float32 input | Needs a battery publisher; no solar physics |
| Spray, sound, LED actions | Abstract alert only | Not implemented; unsafe to assume physical actuation |
| ROS2 Nav2 stack / ros_gz_bridge | Existing project is ROS1 and uses gazebo_ros | Not implemented; migration required |
| Select hardware | `BOM.csv` conceptual parts | Proposed only |
| CAD assembly / cost estimate | Existing TurtleBot3 model, quantities | Detailed CAD & priced BOM outstanding |
| Download/configure ROS2 | No installer performed | Outstanding; environment-dependent |
| Research garden/robot references | See README environment selection | Full literature review outstanding |
| Document progress for final report | `PROGRESS.md`, `TEST_PLAN.md`, this matrix | Documentation authored |
