# Integration notes

Source was the user's uploaded `TheCropCop-main.zip`. The original lab folder and custom scripts were preserved, not overwritten. The previous standalone implementation's `worlds`, `config`, `docs`, and ROS nodes were integrated under the existing `the_crop_cop` package; package metadata and CMake were updated to install the new scripts.

## Existing files and conflicts

- `scripts/field_patrol.py` is an existing odometry waypoint demo that publishes directly to `/cmd_vel`. It remains as coursework/reference **but must not be launched alongside** `decision.py`.
- `scripts/crop_vision_tracker.py`, `motion_primitives.py`, `patrol_node.py`, and `safety_lidar_avoid.py` were empty in the uploaded repo and remain unchanged.
- `labs/` was left untouched.
- `log/` contained generated development records and has been omitted from this deliverable ZIP. These are not source files.

## Safety and correctness

- `patrol.py` zeroes its output if `/scan` or `/odom` is missing or older than 1.5 s (ROS time).
- `decision.py` zeroes `/cmd_vel` when patrol commands are older than 1.0 s or a pest/low-battery condition pauses patrol.
- Red detection is intentionally color-based and may classify unrelated red objects as pests. A real system needs model-based identification and owner verification.
- Do not connect this project to an actual pesticide sprayer without independent hazard analysis and safety controls.
- TurtleBot3 simulation camera plugin topics and Gazebo model availability vary; verify on the host OS.
- Spawn model's physical geometry is the upstream TurtleBot3 Waffle, not original student CAD.

## Verification performed in this package

Python syntax compilation, XML parse for launch/world/package files, package file structural checks, and repository preservation checks. These **are not** ROS/Gazebo integration tests. An installed ROS Noetic + Gazebo environment was unavailable.
