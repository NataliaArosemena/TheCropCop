# Crop Cop validation plan — execution pending

No PASS claims are made until the user runs these in ROS/Gazebo. Capture `/crop_cop/state`, `/cmd_vel`, `/scan`, `/odom`, images, and console output.

| ID | Procedure | Pass criterion |
|---|---|---|
| T01 | Launch `crop_cop_demo.launch` with `TURTLEBOT3_MODEL=waffle` | Gazebo opens with four beds, 12 plants, two insects, obstacle, and robot |
| T02 | Verify `/scan`, `/odom` and `patrol_cmd` | Nonzero patrol commands only after valid scan and odometry arrive |
| T03 | Observe one aisle patrol | Robot visits multiple configured odom waypoints without crop collisions |
| T04 | Place obstacle within 0.48 m directly ahead | Controller commands zero forward velocity and rotates |
| T05 | Stop `/scan` or `/odom` producer >1.5s | Controller sends zero Twist, decision sends zero `/cmd_vel` |
| T06 | Publish BAD string at 5 Hz for >=3 samples | `/crop_cop/state` PEST_ALERT; `/crop_cop/alert` emitted; `/cmd_vel` zero |
| T07 | Publish GOOD or NONE with no BAD | No pest alert triggered solely from those messages |
| T08 | Publish `/crop_cop/battery_pct` 10.0 | RECHARGE_REQUEST + zero velocity |
| T09 | Publish `/crop_cop/battery_pct` 30.0 | Returns to PATROL (when valid patrol commands are available) |
| T10 | Remove camera stream | No new image-derived classifications; no spray actuation |
| T11 | Inspect camera view when red sphere visible | Detect BAD if region exceeds threshold; record false positives |
| T12 | Inspect green plant image with default settings | Green pixels do not cause GOOD classification (feature disabled by default) |

**Example command:** `rostopic pub -r 5 /crop_cop/insect std_msgs/String 'data: "BAD"'` (Ctrl+C after test).

**Safety limitations:** Reactive avoidance is not a certified obstacle avoidance system. No real pesticide sprayer should be activated by color classification.
