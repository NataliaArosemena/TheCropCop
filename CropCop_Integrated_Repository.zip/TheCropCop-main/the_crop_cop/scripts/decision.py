#!/usr/bin/env python3
"""Velocity arbitration and pest alerts (no physical actuation)."""
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool, Float32, String


class Decision:
    def __init__(self):
        self.state = 'PATROL'
        self.battery = 100.0  # default only for simulation; not a live battery reading
        self.patrol = Twist()
        self.last_patrol = None
        self.confirm = max(1, int(rospy.get_param('~pest_confirm_frames', 3)))
        self.low = float(rospy.get_param('~battery_low_pct', 15.0))
        self.cmd_timeout = float(rospy.get_param('~cmd_timeout_s', 1.0))
        self.cooldown = rospy.Duration(float(rospy.get_param('~pest_cooldown_s', 8.0)))
        self.alert_duration = rospy.Duration(float(rospy.get_param('~pest_alert_seconds', 3.0)))
        self.bad_count = 0
        self.last_pest = None
        self.alert_until = rospy.Time(0)
        self.vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.stop_pub = rospy.Publisher('/crop_cop/stop', Bool, queue_size=1)
        self.state_pub = rospy.Publisher('/crop_cop/state', String, queue_size=1, latch=True)
        self.alert_pub = rospy.Publisher('/crop_cop/alert', String, queue_size=10)
        rospy.Subscriber('/crop_cop/patrol_cmd', Twist, self.on_patrol)
        rospy.Subscriber('/crop_cop/insect', String, self.on_insect)
        rospy.Subscriber('/crop_cop/battery_pct', Float32, self.on_battery)
        rospy.on_shutdown(lambda: self.vel_pub.publish(Twist()))

    def on_patrol(self, msg):
        self.patrol = msg
        self.last_patrol = rospy.Time.now()

    def on_battery(self, msg):
        self.battery = msg.data

    def on_insect(self, msg):
        self.bad_count = self.bad_count + 1 if msg.data == 'BAD' else 0

    def tick(self):
        now = rospy.Time.now()
        if self.battery <= self.low or (self.state == 'RECHARGE_REQUEST' and self.battery <= self.low + 5):
            self.state = 'RECHARGE_REQUEST'
        elif now < self.alert_until:
            self.state = 'PEST_ALERT'
        elif self.bad_count >= self.confirm and (self.last_pest is None or now - self.last_pest >= self.cooldown):
            self.state = 'PEST_ALERT'
            self.last_pest = now
            self.alert_until = now + self.alert_duration
            self.alert_pub.publish(String(data='Potential harmful insect: owner verification required. No spray activated.'))
            self.bad_count = 0
        else:
            self.state = 'PATROL'
        stale = self.last_patrol is None or (now - self.last_patrol).to_sec() > self.cmd_timeout
        halted = self.state != 'PATROL' or stale
        self.stop_pub.publish(Bool(data=halted))
        self.state_pub.publish(String(data=self.state if not stale else 'WAITING_FOR_PATROL' if self.state == 'PATROL' else self.state))
        self.vel_pub.publish(Twist() if halted else self.patrol)


if __name__ == '__main__':
    rospy.init_node('crop_cop_decision')
    node = Decision()
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        node.tick()
        rate.sleep()
