#!/usr/bin/env python3
"""Classifies stationary red/green blobs in camera images; demo-only heuristic."""
import cv2
import numpy as np
import rospy
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image
from std_msgs.msg import String
class Vision:
    def __init__(self):
        self.bridge=CvBridge(); self.pub=rospy.Publisher('/crop_cop/insect',String,queue_size=5)
        self.area=rospy.get_param('~min_blob_area_px',130)
        self.enable_green=rospy.get_param('~enable_green_classification',False)
        self.red1=(np.array(rospy.get_param('~harmful_red_low_1',[0,120,80]),dtype=np.uint8),np.array(rospy.get_param('~harmful_red_high_1',[10,255,255]),dtype=np.uint8))
        self.red2=(np.array(rospy.get_param('~harmful_red_low_2',[170,120,80]),dtype=np.uint8),np.array(rospy.get_param('~harmful_red_high_2',[179,255,255]),dtype=np.uint8))
        self.green=(np.array(rospy.get_param('~helpful_green_low',[35,80,60]),dtype=np.uint8),np.array(rospy.get_param('~helpful_green_high',[85,255,255]),dtype=np.uint8))
        rospy.Subscriber(rospy.get_param('~image_topic','/camera/rgb/image_raw'),Image,self.cb,queue_size=1,buff_size=2**24)
    def cb(self,msg):
        try: bgr=self.bridge.imgmsg_to_cv2(msg,'bgr8')
        except CvBridgeError as e: rospy.logwarn(str(e));return
        hsv=cv2.cvtColor(bgr,cv2.COLOR_BGR2HSV)
        red=cv2.bitwise_or(cv2.inRange(hsv,*self.red1),cv2.inRange(hsv,*self.red2))
        green=cv2.inRange(hsv,*self.green)
        def largest(mask):
            contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            return max((cv2.contourArea(c) for c in contours),default=0)
        r,g=largest(red),largest(green)
        label='BAD' if r>=self.area and r>g else 'GOOD' if self.enable_green and g>=self.area else 'NONE'
        self.pub.publish(String(data=label))
if __name__=='__main__':
    rospy.init_node('crop_cop_vision');Vision();rospy.spin()
