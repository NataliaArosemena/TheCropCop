#!/usr/bin/env python3
"""Reactive ROS1 waypoint patrol. Publishes patrol_cmd, never cmd_vel directly."""
import math
import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Bool
from tf.transformations import euler_from_quaternion


def wrap_angle(theta):
    return math.atan2(math.sin(theta), math.cos(theta))


class Patrol:
    def __init__(self):
        self.points = rospy.get_param('~waypoints', [])
        self.stop = float(rospy.get_param('~stop_distance_m', 0.48))
        self.slow = float(rospy.get_param('~slow_distance_m', 0.85))
        self.vmax = float(rospy.get_param('~max_linear_mps', 0.13))
        self.wmax = float(rospy.get_param('~max_angular_rps', 0.65))
        self.tol = float(rospy.get_param('~waypoint_tolerance_m', 0.25))
        self.timeout = float(rospy.get_param('~sensor_timeout_s', 1.5))
        self.pose = None
        self.last_odom = None
        self.last_scan = None
        self.front = float('inf')
        self.left = float('inf')
        self.right = float('inf')
        self.halt = False
        self.index = 0
        self.pub = rospy.Publisher('/crop_cop/patrol_cmd', Twist, queue_size=1)
        rospy.Subscriber('/odom', Odometry, self.on_odom)
        rospy.Subscriber('/scan', LaserScan, self.on_scan)
        rospy.Subscriber('/crop_cop/stop', Bool, self.on_stop)
        rospy.on_shutdown(lambda: self.pub.publish(Twist()))

    def on_stop(self, msg):
        self.halt = msg.data

    def on_odom(self, msg):
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        self.pose = (p.x, p.y, euler_from_quaternion([q.x, q.y, q.z, q.w])[2])
        self.last_odom = rospy.Time.now()

    def on_scan(self, msg):
        sectors = [[], [], []]
        for i, r in enumerate(msg.ranges):
            if not math.isfinite(r) or r < msg.range_min or r > msg.range_max:
                continue
            a = wrap_angle(msg.angle_min + i * msg.angle_increment)
            if abs(a) <= math.radians(30):
                sectors[0].append(r)
            elif 0 < a < math.radians(110):
                sectors[1].append(r)
            elif -math.radians(110) < a < 0:
                sectors[2].append(r)
        self.front, self.left, self.right = [min(s) if s else float('inf') for s in sectors]
        self.last_scan = rospy.Time.now()

    def step(self):
        cmd = Twist()
        now = rospy.Time.now()
        if (self.halt or self.pose is None or not self.points or
                self.last_odom is None or self.last_scan is None or
                (now - self.last_odom).to_sec() > self.timeout or
                (now - self.last_scan).to_sec() > self.timeout):
            self.pub.publish(cmd)
            return
        if self.front < self.stop:
            # Rotate without forward movement; stop if insufficient space in either direction.
            cmd.angular.z = -self.wmax if self.left < self.right else self.wmax
        else:
            x, y, yaw = self.pose
            gx, gy = self.points[self.index]
            dx, dy = gx - x, gy - y
            if math.hypot(dx, dy) < self.tol:
                self.index = (self.index + 1) % len(self.points)
                self.pub.publish(cmd)
                return
            error = wrap_angle(math.atan2(dy, dx) - yaw)
            cmd.angular.z = max(-self.wmax, min(self.wmax, 1.5 * error))
            if abs(error) <= 0.65:
                cmd.linear.x = self.vmax * (0.45 if self.front < self.slow else 1.0)
        self.pub.publish(cmd)


if __name__ == '__main__':
    rospy.init_node('crop_cop_patrol')
    node = Patrol()
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        node.step()
        rate.sleep()
