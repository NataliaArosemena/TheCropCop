#!/usr/bin/env python3
"""Offline structural sanity checks; not a substitute for running Gazebo/ROS."""
from pathlib import Path
import ast
import xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1] / 'the_crop_cop'
for name in ['scripts/patrol.py','scripts/vision.py','scripts/decision.py']:
    ast.parse((root/name).read_text(), filename=str(root/name))
    print('OK Python syntax:', name)
for name in ['package.xml','launch/custom_garden.launch','launch/crop_cop_nodes.launch',
             'launch/crop_cop_demo.launch','launch/auto_mapping.launch','worlds/crop_garden.world']:
    ET.parse(root/name)
    print('OK XML:',name)
scene=ET.parse(root/'worlds/crop_garden.world')
models=[n.get('name') for n in scene.findall('.//model')]
assert sum(n.startswith('crop_bed_') for n in models)==4
assert sum(n.startswith('plant_') for n in models)==12
assert 'harmful_red_bug' in models and 'helpful_green_bug' in models
assert 'obstacle' in models
print('OK world model structure')
print('All offline structural checks passed (ROS/Gazebo NOT tested).')
